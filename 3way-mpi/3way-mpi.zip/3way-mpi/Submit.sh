#!/bin/bash
#SBATCH --job-name=hw4-mpi
#SBATCH --output=logs/%x/out_%j.txt
#SBATCH --error=logs/%x/err_%j.txt
#SBATCH --time=00:10:00
#SBATCH --constraint=moles
#SBATCH --nodes=1
#SBATCH --ntasks=8
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=128M

make

echo "Type: $TEST_TYPE"
echo "Param: $PARAM"
echo "Tasks: $SLURM_NTASKS"
echo "Nodes: $SLURM_JOB_NUM_NODES"
echo "Mem per CPU: $SLURM_MEM_PER_CPU"

# Use srun instead of mpirun
/usr/bin/time -v srun ./pt2 > /dev/null
