#!/bin/bash

echo "Jobid,Type,Param,Tasks,Nodes,Mem,Time_sec,CPU_percent,Exit_status" > results.csv

for out in logs/*/out_*.txt
do
    err="${out/out_/err_}"

    type=$(echo "$out" | cut -d'/' -f2)
    base=$(basename "$out" .txt)

    jobid=$(echo "$base" | awk -F'_' '{print $NF}')
    param=$(echo "$base" | sed 's/out_\(.*\)_[0-9]*$/\1/')

    tasks=""
    nodes=""
    mem=""

    tasks=$(awk '/Tasks:/ {print $2}' "$out")
    nodes=$(awk '/Nodes:/ {print $2}' "$out")
    mem=$(awk '/Mem per CPU:/ {print $4}' "$out")

    time=$(awk -F': ' '/Elapsed \(wall clock\)/ {print $2}' "$err")
    cpu=$(awk '/Percent of CPU/ {gsub("%","",$7); print $7}' "$err")
    exit_status=$(awk -F': ' '/Exit status/ {print $2}' "$err")

    echo "$jobid,$type,$param,$tasks,$nodes,$mem,$time,$cpu,$exit_status" >> results.csv
done
