#!/bin/bash
#SBATCH --job-name=hw4-mpi
#SBATCH --output=hw4-mpi.out
#SBATCH --error=hw4-mpi.err
#SBATCH --time=00:10:00
#SBATCH --nodes=8           #param to change
#SBATCH --ntasks=4          #param to change
#SBATCH --cpus-per-task=1   #Keep at 1
#SBATCH --mem-per-cpu=512MB    #param to change
#SBATCH --constraint=moles

module load OpenMPI/4.1.4-GCC-11.3.0

make
/usr/bin/time -v mpirun -np $SLURM_NTASKS ./pt2 > /dev/null

